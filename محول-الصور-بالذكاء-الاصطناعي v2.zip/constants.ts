import { Filter } from './types';

export const CATEGORIES = {
  CINEMATIC: 'Cinematic',
  ARTISTIC: 'Artistic',
  FUTURISTIC: 'Futuristic',
  VINTAGE: 'Vintage',
  ANIMATION: 'Animation',
  FANTASY: 'Fantasy',
  ABSTRACT: 'Abstract',
  PHOTOGRAPHY: 'Photography',
  ILLUSTRATION: 'Illustration',
  GAMING: 'Gaming',
};

const PREVIEW_IMAGES: { [key: string]: string[] } = {
    [CATEGORIES.CINEMATIC]: [
        'https://storage.googleapis.com/gemini-ui-params/prompts/images/cinematic-1.webp',
        'https://storage.googleapis.com/gemini-ui-params/prompts/images/cinematic-2.webp',
        'https://storage.googleapis.com/gemini-ui-params/prompts/images/cinematic-3.webp',
    ],
    [CATEGORIES.ARTISTIC]: [
        'https://storage.googleapis.com/gemini-ui-params/prompts/images/artistic-1.webp',
        'https://storage.googleapis.com/gemini-ui-params/prompts/images/artistic-2.webp',
        'https://storage.googleapis.com/gemini-ui-params/prompts/images/artistic-3.webp',
    ],
    [CATEGORIES.FUTURISTIC]: [
        'https://storage.googleapis.com/gemini-ui-params/prompts/images/futuristic-1.webp',
        'https://storage.googleapis.com/gemini-ui-params/prompts/images/futuristic-2.webp',
    ],
    [CATEGORIES.VINTAGE]: [
        'https://storage.googleapis.com/gemini-ui-params/prompts/images/vintage-1.webp',
        'https://storage.googleapis.com/gemini-ui-params/prompts/images/vintage-2.webp',
    ],
    [CATEGORIES.ANIMATION]: [
        'https://storage.googleapis.com/gemini-ui-params/prompts/images/animation-1.webp',
        'https://storage.googleapis.com/gemini-ui-params/prompts/images/animation-2.webp',
    ],
     [CATEGORIES.FANTASY]: [
        'https://storage.googleapis.com/gemini-ui-params/prompts/images/fantasy-1.webp',
        'https://storage.googleapis.com/gemini-ui-params/prompts/images/fantasy-2.webp',
    ],
    [CATEGORIES.ABSTRACT]: [
        'https://storage.googleapis.com/gemini-ui-params/prompts/images/abstract-1.webp',
        'https://storage.googleapis.com/gemini-ui-params/prompts/images/abstract-2.webp',
    ],
    [CATEGORIES.PHOTOGRAPHY]: [
         'https://storage.googleapis.com/gemini-ui-params/prompts/images/photography-1.webp',
    ],
    [CATEGORIES.ILLUSTRATION]: [
        'https://storage.googleapis.com/gemini-ui-params/prompts/images/illustration-1.webp',
    ],
    [CATEGORIES.GAMING]: [
        'https://storage.googleapis.com/gemini-ui-params/prompts/images/gaming-1.webp',
    ],
};

const initialFilters: Filter[] = [
  // A few hand-picked ones to ensure they appear first
  { id: 'cinematic-1', name: 'Epic Movie', category: CATEGORIES.CINEMATIC, baseQuery: 'cinematic, dramatic lighting, epic, movie still, highly detailed', previewImageUrl: PREVIEW_IMAGES[CATEGORIES.CINEMATIC][0] },
  { id: 'artistic-1', name: 'Oil Painting', category: CATEGORIES.ARTISTIC, baseQuery: 'masterpiece oil painting, visible brushstrokes, rich colors, classical style', previewImageUrl: PREVIEW_IMAGES[CATEGORIES.ARTISTIC][0] },
  { id: 'animation-1', name: 'Anime', category: CATEGORIES.ANIMATION, baseQuery: '90s anime style, vibrant, cel-shaded, classic anime aesthetic', previewImageUrl: PREVIEW_IMAGES[CATEGORIES.ANIMATION][0] },
  { id: 'futuristic-1', name: 'Cyberpunk', category: CATEGORIES.FUTURISTIC, baseQuery: 'cyberpunk city, neon-drenched, dystopian, futuristic technology, high-tech', previewImageUrl: PREVIEW_IMAGES[CATEGORIES.FUTURISTIC][0] },
];

const generatedFilters = new Set(initialFilters.map(f => f.name));

const styleComponents = {
  era: ['Victorian', 'Renaissance', 'Ancient Roman', '1920s Art Deco', '1950s Retro', '1980s Neon', 'Steampunk', 'Dieselpunk'],
  style: ['Minimalist', 'Maximalist', 'Gothic', 'Surrealist', 'Cubist', 'Expressionist', 'Pop Art', 'Bauhaus', 'Rococo'],
  technique: ['Double Exposure', 'Long Exposure', 'Glitch Art', 'Pixel Art', 'Vector Art', 'Low Poly', 'Chiaroscuro', 'Tenebrism'],
  material: ['Marble Sculpture', 'Bronze Cast', 'Origami', 'Quilling', 'Stained Glass', 'Mosaic', 'Woodcut Print', 'Chalk Drawing'],
  lighting: ['Volumetric', 'Rim Lighting', 'Studio Lighting', 'Softbox', 'Golden Hour', 'Blue Hour', 'Moonlit', 'Bioluminescent'],
  adjective: ['Ethereal', 'Gritty', 'Whimsical', 'Melancholy', 'Serene', 'Chaotic', 'Opulent', 'Rustic', 'Psychedelic'],
  artist: ['in the style of Van Gogh', 'in the style of da Vinci', 'in the style of Hokusai', 'in the style of Picasso', 'in the style of Rembrandt', 'in the style of Banksy'],
  concept: ['Cosmic Horror', 'Solarpunk', 'Fairy Tale', 'Mythological', 'Post-Apocalyptic', 'Utopian', 'Hard Sci-Fi', 'Space Opera'],
  game: ['RPG Game Art', '8-Bit Retro Game', 'Modern AAA Game', 'Indie Game Aesthetic', 'Cel-Shaded Game']
};

const categoryMapping: { [key: string]: (keyof typeof styleComponents)[] } = {
    [CATEGORIES.CINEMATIC]: ['lighting', 'era', 'concept'],
    [CATEGORIES.ARTISTIC]: ['style', 'artist', 'technique', 'material'],
    [CATEGORIES.FUTURISTIC]: ['concept', 'lighting', 'adjective'],
    [CATEGORIES.VINTAGE]: ['era', 'technique'],
    [CATEGORIES.ANIMATION]: ['style', 'technique', 'artist'],
    [CATEGORIES.FANTASY]: ['concept', 'adjective', 'era'],
    [CATEGORIES.ABSTRACT]: ['style', 'technique', 'adjective'],
    [CATEGORIES.PHOTOGRAPHY]: ['technique', 'lighting'],
    [CATEGORIES.ILLUSTRATION]: ['material', 'style'],
    [CATEGORIES.GAMING]: ['game', 'style'],
};

function generateUniqueFilters(targetCount: number): Filter[] {
    const allFilters: Filter[] = [...initialFilters];
    let attempt = 0;

    while (allFilters.length < targetCount && attempt < targetCount * 5) {
        const category = Object.keys(categoryMapping)[Math.floor(Math.random() * Object.keys(categoryMapping).length)];
        const componentKeys = categoryMapping[category];

        const part1Key = componentKeys[Math.floor(Math.random() * componentKeys.length)];
        const part2Key = componentKeys[Math.floor(Math.random() * componentKeys.length)];
        
        const part1 = styleComponents[part1Key][Math.floor(Math.random() * styleComponents[part1Key].length)];
        let part2 = styleComponents[part2Key][Math.floor(Math.random() * styleComponents[part2Key].length)];

        if (part1 === part2) {
            part2 = styleComponents[part2Key][(Math.floor(Math.random() * (styleComponents[part2Key].length -1)) + 1) % styleComponents[part2Key].length];
        }

        const name = `${part1} ${part2}`;
        if (!generatedFilters.has(name)) {
            generatedFilters.add(name);
            const previewPool = PREVIEW_IMAGES[category] || PREVIEW_IMAGES[CATEGORIES.ARTISTIC];
            const previewImageUrl = previewPool[Math.floor(Math.random() * previewPool.length)];

            allFilters.push({
                id: `gen-${allFilters.length}`,
                name: name,
                category: category,
                baseQuery: `${name}, high resolution, detailed, professional`,
                previewImageUrl: previewImageUrl,
            });
        }
        attempt++;
    }
    return allFilters;
}


export const FILTERS: Filter[] = generateUniqueFilters(1000);