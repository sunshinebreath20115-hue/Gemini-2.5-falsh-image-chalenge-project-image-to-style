import React, { useState, useCallback } from 'react';
import type { Filter } from './types';
import { applyImageEffect, generatePromptForStyle } from './services/geminiService';
import Header from './components/Header';
import ImageUploader from './components/ImageUploader';
import FilterSelector from './components/FilterSelector';
import ImageDisplay from './components/ImageDisplay';
import Loader from './components/Loader';
import { SparklesIcon } from './components/icons/SparklesIcon';

const App: React.FC = () => {
  const [sourceImage, setSourceImage] = useState<File | null>(null);
  const [sourceImageUrl, setSourceImageUrl] = useState<string | null>(null);
  const [generatedImageUrl, setGeneratedImageUrl] = useState<string | null>(null);
  const [selectedFilter, setSelectedFilter] = useState<Filter | null>(null);
  const [isLoadingPrompt, setIsLoadingPrompt] = useState<boolean>(false);
  const [isLoadingImage, setIsLoadingImage] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [generatedPrompt, setGeneratedPrompt] = useState<string>('');

  const handleImageUpload = (file: File) => {
    setSourceImage(file);
    setSourceImageUrl(URL.createObjectURL(file));
    setGeneratedImageUrl(null);
    setError(null);
    // If a filter is already selected, generate a new prompt for the new image
    if (selectedFilter) {
      handleFilterSelect(selectedFilter);
    }
  };
  
  const handleFilterSelect = useCallback(async (filter: Filter) => {
      setSelectedFilter(filter);
      setGeneratedImageUrl(null); // Clear previous image result
      setGeneratedPrompt(''); // Clear previous prompt
      setError(null);

      if (!sourceImage) {
        // Don't generate a prompt yet if there's no image
        return;
      }

      setIsLoadingPrompt(true);
      try {
        const prompt = await generatePromptForStyle(filter.baseQuery);
        setGeneratedPrompt(prompt);
      } catch (e) {
        console.error(e);
        setError('فشل في إنشاء الأمر. يرجى المحاولة مرة أخرى.');
      } finally {
        setIsLoadingPrompt(false);
      }
    },
    [sourceImage]
  );


  const handleGenerateImage = useCallback(async () => {
    if (!sourceImage || !generatedPrompt) {
      setError('يرجى تحميل صورة واختيار فلتر لإنشاء أمر أولاً.');
      return;
    }

    setIsLoadingImage(true);
    setGeneratedImageUrl(null);
    setError(null);

    try {
      const result = await applyImageEffect(sourceImage, generatedPrompt);
      if (result.imageUrl) {
        setGeneratedImageUrl(result.imageUrl);
      } else {
          setError(result.text || 'فشل في إنشاء الصورة. قد يكون المحتوى غير مسموح به.');
      }
    } catch (e) {
      console.error(e);
      setError('حدث خطأ غير متوقع. يرجى المحاولة مرة أخرى.');
    } finally {
      setIsLoadingImage(false);
    }
  }, [sourceImage, generatedPrompt]);
  
  const isGenerating = isLoadingPrompt || isLoadingImage;

  return (
    <div className="min-h-screen bg-gray-900 text-gray-100 flex flex-col">
      <Header />
      <main className="flex-grow container mx-auto p-4 md:p-8 flex flex-col lg:flex-row gap-8">
        {/* Controls Column */}
        <div className="lg:w-1/3 flex flex-col gap-6">
          <div className="bg-gray-800 rounded-xl p-6 shadow-lg">
            <h2 className="text-xl font-bold mb-4 text-cyan-400">الخطوة 1: تحميل الصورة</h2>
            <ImageUploader onImageUpload={handleImageUpload} />
          </div>

          <div className="bg-gray-800 rounded-xl p-6 shadow-lg">
            <h2 className="text-xl font-bold mb-4 text-cyan-400">الخطوة 2: اختيار الستايل</h2>
            <FilterSelector
              selectedFilter={selectedFilter}
              onSelectFilter={handleFilterSelect}
              disabled={!sourceImage}
            />
          </div>
          
          <div className="bg-gray-800 rounded-xl p-6 shadow-lg">
             <div className="flex items-center gap-2 mb-2">
                <h2 className="text-xl font-bold text-cyan-400">الخطوة 3: مراجعة الأمر</h2>
                {isLoadingPrompt && <Loader />}
             </div>
            <p className="text-sm text-gray-400 mb-4">هذا هو الأمر الاحترافي الذي تم إنشاؤه. يمكنك تعديله!</p>
             <textarea
              className="w-full bg-gray-700 border border-gray-600 rounded-lg p-3 text-white placeholder-gray-400 focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 transition"
              rows={4}
              placeholder={isLoadingPrompt ? "جاري إنشاء الأمر بواسطة الذكاء الاصطناعي..." : "اختر ستايلاً لإنشاء الأمر هنا..."}
              value={generatedPrompt}
              onChange={(e) => setGeneratedPrompt(e.target.value)}
              disabled={!sourceImage || !selectedFilter || isLoadingPrompt}
            />
          </div>

          <button
            onClick={handleGenerateImage}
            disabled={!sourceImage || !generatedPrompt || isGenerating}
            className="w-full flex items-center justify-center gap-3 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 text-white font-bold py-4 px-6 rounded-xl text-lg shadow-lg transition-all duration-300 ease-in-out disabled:opacity-50 disabled:cursor-not-allowed transform hover:scale-105"
          >
            {isLoadingImage ? (
              <>
                <Loader />
                جاري الإنشاء...
              </>
            ) : (
              <>
                <SparklesIcon />
                أنشئ الصورة السحرية
              </>
            )}
          </button>
          {error && <p className="text-red-400 mt-4 text-center">{error}</p>}
        </div>

        {/* Image Display Column */}
        <div className="lg:w-2/3 bg-gray-800 rounded-xl p-6 shadow-lg">
            <ImageDisplay
              sourceImageUrl={sourceImageUrl}
              generatedImageUrl={generatedImageUrl}
              isLoading={isLoadingImage}
              loadingText="الذكاء الاصطناعي يعمل بسحره..."
            />
        </div>
      </main>
    </div>
  );
};

export default App;
