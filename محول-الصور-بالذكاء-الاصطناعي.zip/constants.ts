import type { Filter } from './types';

export const CATEGORIES = {
  CINEMATIC: 'سينمائي',
  ARTISTIC: 'فني',
  FANTASY_SCI_FI: 'خيال وخيال علمي',
  VINTAGE: 'عتيق',
  ANIMATION: 'رسوم متحركة',
  MODERN: 'حديث',
};

export const FILTERS: Filter[] = [
  // Cinematic
  {
    id: 'cinematic-noir',
    name: 'سينمائي نوير',
    category: CATEGORIES.CINEMATIC,
    baseQuery: 'A high-contrast black and white masterpiece in the classic film noir style, focusing on dramatic shadows and a moody atmosphere.',
    previewImageUrl: 'https://picsum.photos/id/10/200/200',
  },
  {
    id: 'epic-blockbuster',
    name: 'فيلم ضخم',
    category: CATEGORIES.CINEMATIC,
    baseQuery: 'A cinematic blockbuster movie look with teal and orange color grading, high dynamic range, and an epic, dramatic feel.',
    previewImageUrl: 'https://picsum.photos/id/101/200/200',
  },
  {
    id: 'dramatic-lighting',
    name: 'إضاءة درامية',
    category: CATEGORIES.CINEMATIC,
    baseQuery: 'A scene with dramatic, moody lighting, using chiaroscuro techniques to create deep contrast between light and shadow, evoking a sense of mystery.',
    previewImageUrl: 'https://picsum.photos/id/119/200/200',
  },
  // Artistic
  {
    id: 'watercolor-dream',
    name: 'ألوان مائية حالمة',
    category: CATEGORIES.ARTISTIC,
    baseQuery: 'A delicate and luminous watercolor painting with soft, blended washes for the background and detailed brushwork for the main subjects.',
    previewImageUrl: 'https://picsum.photos/id/1015/200/200',
  },
  {
    id: 'pop-art',
    name: 'فن البوب',
    category: CATEGORIES.ARTISTIC,
    baseQuery: 'A bold Andy Warhol-style pop art transformation with vibrant, unexpected colors, a clear halftone pattern, and strong outlines.',
    previewImageUrl: 'https://picsum.photos/id/1059/200/200',
  },
  {
    id: 'oil-painting',
    name: 'لوحة زيتية',
    category: CATEGORIES.ARTISTIC,
    baseQuery: 'A classical oil painting with rich textures, visible brushstrokes, and a deep, vibrant color palette reminiscent of the Old Masters.',
    previewImageUrl: 'https://picsum.photos/id/1041/200/200',
  },
  {
    id: 'charcoal-sketch',
    name: 'رسم بالفحم',
    category: CATEGORIES.ARTISTIC,
    baseQuery: 'A dramatic and expressive charcoal sketch, focusing on texture, shading, and form with a high-contrast, monochrome aesthetic.',
    previewImageUrl: 'https://picsum.photos/id/1066/200/200',
  },
  // Animation
  {
    id: 'anime-vibrant',
    name: 'أسلوب الأنمي',
    category: CATEGORIES.ANIMATION,
    baseQuery: 'A vibrant, high-quality anime illustration with large expressive eyes, cel-shaded coloring, and a beautifully painted, soft-focus background.',
    previewImageUrl: 'https://picsum.photos/id/1067/200/200',
  },
  {
    id: 'pixar-3d',
    name: 'ثلاثي الأبعاد',
    category: CATEGORIES.ANIMATION,
    baseQuery: 'A 3D animated character style, with soft lighting, detailed textures, and the charming, expressive quality of a modern animated film.',
    previewImageUrl: 'https://picsum.photos/id/135/200/200',
  },
  {
    id: 'classic-cartoon',
    name: 'كرتون كلاسيكي',
    category: CATEGORIES.ANIMATION,
    baseQuery: 'A classic 1950s cartoon style with simple shapes, bold outlines, and a bright, cheerful color palette.',
    previewImageUrl: 'https://picsum.photos/id/163/200/200',
  },
  // Fantasy & Sci-Fi
  {
    id: 'cyberpunk-neon',
    name: 'سايبربانك نيون',
    category: CATEGORIES.FANTASY_SCI_FI,
    baseQuery: 'A neon-drenched cyberpunk aesthetic with vibrant electric pinks and cyan blues, holographic glows, and wet, reflective surfaces.',
    previewImageUrl: 'https://picsum.photos/id/1075/200/200',
  },
  {
    id: 'fantasy-epic',
    name: 'ملحمة خيالية',
    category: CATEGORIES.FANTASY_SCI_FI,
    baseQuery: 'An epic fantasy world scene with dramatic, divine lighting, rich, deep colors, and ethereal elements like glowing mist or floating particles.',
    previewImageUrl: 'https://picsum.photos/id/1043/200/200',
  },
  {
    id: 'steampunk-gears',
    name: 'ستيم بانك',
    category: CATEGORIES.FANTASY_SCI_FI,
    baseQuery: 'A steampunk-inspired image with intricate clockwork, gears, polished brass, and a warm, sepia-toned color palette.',
    previewImageUrl: 'https://picsum.photos/id/225/200/200',
  },
  // Vintage
  {
    id: 'vintage-film',
    name: 'فيلم قديم',
    category: CATEGORIES.VINTAGE,
    baseQuery: 'A 1970s vintage film photograph with a warm color grade, subtle film grain, slightly faded shadows, and soft-glowing highlights.',
    previewImageUrl: 'https://picsum.photos/id/1080/200/200',
  },
  {
    id: 'daguerreotype',
    name: 'داجيروتايب',
    category: CATEGORIES.VINTAGE,
    baseQuery: 'An antique daguerreotype photograph from the 19th century, with a silvery, metallic sheen, high detail, and a haunting, timeless quality.',
    previewImageUrl: 'https://picsum.photos/id/234/200/200',
  },
  // Modern
  {
    id: 'minimalist-bw',
    name: 'بساطة أبيض وأسود',
    category: CATEGORIES.MODERN,
    baseQuery: 'A minimal black and white photograph focusing on form, composition, and negative space, with strong contrast and clean lines.',
    previewImageUrl: 'https://picsum.photos/id/219/200/200',
  },
  {
    id: 'double-exposure',
    name: 'تعريض مزدوج',
    category: CATEGORIES.MODERN,
    baseQuery: 'A creative double exposure effect, blending the main subject with a nature or cityscape scene in a seamless and artistic way.',
    previewImageUrl: 'https://picsum.photos/id/201/200/200',
  },
];
