export interface Filter {
  id: string;
  name: string;
  category: string;
  baseQuery: string;
  previewImageUrl: string;
}
