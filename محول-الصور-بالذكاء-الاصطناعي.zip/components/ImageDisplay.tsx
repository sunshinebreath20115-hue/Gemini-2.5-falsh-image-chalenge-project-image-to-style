import React from 'react';
import Loader from './Loader';
import { PhotoIcon } from './icons/PhotoIcon';

interface ImageDisplayProps {
  sourceImageUrl: string | null;
  generatedImageUrl: string | null;
  isLoading: boolean;
  loadingText?: string;
}

const ImagePanel: React.FC<{ imageUrl: string | null; title: string; isLoading?: boolean; loadingText?: string }> = ({ imageUrl, title, isLoading = false, loadingText }) => {
    return (
        <div className="w-full flex flex-col items-center">
            <h3 className="text-lg font-bold text-gray-300 mb-4">{title}</h3>
            <div className="aspect-square w-full bg-gray-900/50 rounded-lg flex items-center justify-center overflow-hidden border-2 border-gray-700">
                {isLoading ? (
                    <div className="flex flex-col items-center text-gray-400 p-4 text-center">
                      <Loader />
                      <p className="mt-4">{loadingText || 'جاري التحميل...'}</p>
                    </div>
                ) : imageUrl ? (
                    <img src={imageUrl} alt={title} className="w-full h-full object-contain" />
                ) : (
                    <div className="flex flex-col items-center text-gray-500">
                        <PhotoIcon className="w-16 h-16"/>
                        <p className="mt-2">{title === 'الأصلية' ? 'لم يتم تحميل صورة بعد' : 'النتيجة ستظهر هنا'}</p>
                    </div>
                )}
            </div>
        </div>
    );
}

const ImageDisplay: React.FC<ImageDisplayProps> = ({ sourceImageUrl, generatedImageUrl, isLoading, loadingText }) => {
  return (
    <div className="flex flex-col md:flex-row gap-6 items-center w-full">
      <ImagePanel imageUrl={sourceImageUrl} title="الأصلية" />
      <ImagePanel imageUrl={generatedImageUrl} title="المعدلة" isLoading={isLoading} loadingText={loadingText} />
    </div>
  );
};

export default ImageDisplay;
